#ifndef _failed_h_INCLUDED
#define _failed_h_INCLUDED

struct kissat;

void kissat_failed_literal_computation (struct kissat *);

#endif
