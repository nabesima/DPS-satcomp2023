#!/bin/bash

# default compilers
[ -z "$CC" ] && CC=gcc
[ -z "$CXX" ] && CXX=g++
# default is silent mode
VERBOSE=0

while getopts giv OPT
do
  case $OPT in
    i) 
        CC=icc
        CXX=icpc
        ;;     
    g) 
        CC=gcc
        CXX=g++
        ;;     
    v)
        VERBOSE=1
        ;;
    *)
        exit 1
        ;;        
  esac
done
shift $((OPTIND - 1))

TARGET="r"

if [ $# -ge 1 ]; then
    TARGET=$1
fi

if [ ${TARGET} = "d" ]; then
    # From cmake-3.13, the following simple instructions are avairable
    # cmake -B Debug -DCMAKE_BUILD_TYPE=Debug
    # cmake --build Debug 
    mkdir -p Debug
    cd Debug
    cmake .. -DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_COMPILER=${CC} -DCMAKE_CXX_COMPILER=${CXX} -DCMAKE_VERBOSE_MAKEFILE=${VERBOSE}

    cmake --build .
    cd ..
elif [ ${TARGET} = "r" ]; then
    # From cmake-3.13, the following simple instructions are avairable
    # cmake -B Release -DCMAKE_BUILD_TYPE=Release
    # cmake --build Release 
    mkdir -p Release
    cd Release
    cmake .. -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=${CC} -DCMAKE_CXX_COMPILER=${CXX} -DCMAKE_VERBOSE_MAKEFILE=${VERBOSE}
    cmake --build .
    cd ..
elif [ ${TARGET} = "c" ]; then
    if [ -f "Release/Makefile" ]; then
        cd Release
        make clean
        cd ..
    fi
    if [ -f "Debug/Makefile" ]; then
        cd Debug
        make clean
        cd ..
    fi
fi

