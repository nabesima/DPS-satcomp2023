#include "ThreadLocalVars.h"

namespace DPS {
    thread_local uint64_t num_mem_accesses;
}
